# SpringBootReact
Spring Boot + React.js

Simple CRUD application with Spring Boot Data REST backend and React.js frontend. Application uses H2 runtime database and contains demodata.

Launch by typing: mvnw spring-boot:run

Please connect to internet acess before running

    H2
    JPA
    REST
    React.js

