package sample.mozanta.tech.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
    private @Id @GeneratedValue Long id;
    private String name, dob, stdclass,division,gender;
    private String addmNum;
 
    public String getAddmNum() {
		return addmNum;
	}

	public void setAddmNum(String addmNum) {
		this.addmNum = addmNum;
	}

	private Student() {}
 
    public Student(String name, String dob, String stdclass, String division, String gender,String addmNum) {
        this.name = name;
        this.dob = dob;
        this.stdclass = stdclass;
        this.division = division;
        this.gender = gender;
        this.addmNum = addmNum;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getStdclass() {
		return stdclass;
	}

	public void setStdclass(String stdclass) {
		this.stdclass = stdclass;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
   
}