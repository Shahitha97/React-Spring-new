package sample.mozanta.tech.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sample.mozanta.tech.domain.Student;
import sample.mozanta.tech.domain.StudentRepository;

@Controller
public class HomeController {
 
    @RequestMapping(value = "/")
    public String index() {
        return "index.html";
    }
    private final StudentRepository studentRepository;
	 
    @Autowired
    public HomeController(StudentRepository studentRepository) {
	 this.studentRepository = studentRepository;
    }
   
    
    @RequestMapping(value = "/api/createStudent", method = RequestMethod.POST)
	public Student createStudent(@RequestBody Student student) {
		if (null != student) {
			if (!student.getName().isEmpty() && !student.getDob().isEmpty()) {
				student.setAddmNum("R-"+ ((int)(Math.random()*9000)+1000));
				return studentRepository.save(student);
			}

		}
		return student;
	}
    
   
}
