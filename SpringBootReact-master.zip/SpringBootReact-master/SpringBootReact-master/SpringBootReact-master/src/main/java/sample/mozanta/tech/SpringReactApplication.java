package sample.mozanta.tech;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import sample.mozanta.tech.domain.StudentRepository;

@SpringBootApplication
public class SpringReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringReactApplication.class, args);
	}
	
	
	@Component
	public class DatabaseLoader implements CommandLineRunner {
	 
	    private final StudentRepository repository;
	 
	    @Autowired
	    public DatabaseLoader(StudentRepository repository) {
	        this.repository = repository;
	    }
	 
	    @Override
	    public void run(String... strings) throws Exception {
	        
	    }
	}	
}
