class App extends React.Component {
  constructor(props) {
      super(props);
      this.deleteStudent = this.deleteStudent.bind(this);
      this.createStudent = this.createStudent.bind(this);
      this.state = {
          students: [],
      };
   }
 
  componentDidMount() {
    this.loadStudentsFromServer();
  }
  
  // Load students from database
  loadStudentsFromServer() {
      fetch('http://localhost:8080/api/students') 
      .then((response) => response.json()) 
      .then((responseData) => { 
          this.setState({ 
              students: responseData._embedded.students, 
          }); 
      });     
  } 
  
  // Delete student
  deleteStudent(student) {
      fetch (student._links.self.href,
      { method: 'DELETE',})
      .then( 
          res => this.loadStudentsFromServer()
      )
      .catch( err => cosole.error(err))                
  }  
  
  // Create new student
  createStudent(student) {
      fetch('http://localhost:8080/api/createStudent', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(student)
      })
      .then( 
          res => this.loadStudentsFromServer()
      )
      .catch( err => cosole.error(err))
  }
  
  render() {
    return (
       <div>
          <StudentForm createStudent={this.createStudent}/>
          <StudentTable deleteStudent={this.deleteStudent} students={this.state.students}/> 
       </div>
    );
  }
}
    	
class StudentTable extends React.Component {
    constructor(props) {
        super(props);
    }
    
    render() {
    var students = this.props.students.map(student =>
        <Student key={student._links.self.href} student={student} deleteStudent={this.props.deleteStudent}/>
    );

    return (
      <div>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>name</th><th>dob</th><th>class</th><th>division</th><th>gender</th><th>AddmissionNumber</th><th> </th>
          </tr>
        </thead>
        <tbody>{students}</tbody>
      </table>
      </div>);
  }
}
        
class Student extends React.Component {
    constructor(props) {
        super(props);
        this.deleteStudent = this.deleteStudent.bind(this);
    }

    deleteStudent() {
        this.props.deleteStudent(this.props.student);
    } 
 
    render() {
        return (
          <tr>
            <td>{this.props.student.name}</td>
            <td>{this.props.student.dob}</td>
            <td>{this.props.student.stdclass}</td>
			<td>{this.props.student.division}</td>
			<td>{this.props.student.gender}</td>
			<td>{this.props.student.addmNum}</td>
            <td>
                <button className="btn btn-danger" onClick={this.deleteStudent}>Delete</button>
            </td>
          </tr>
        );
    } 
}

class StudentForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {name: '', dob: '', stdclass: '',division: '',gender: '',addmNum:''};
        this.handleSubmit = this.handleSubmit.bind(this);   
        this.handleChange = this.handleChange.bind(this);     
    }

    handleChange(event) {
        console.log("NAME: " + event.target.name + " VALUE: " + event.target.value)
        this.setState(
            {[event.target.name]: event.target.value}
        );
    }   
   
    handleSubmit(event) {
        event.preventDefault();
	if(!this.state.name || !this.state.dob || !this.state.stdclass ||!this.state.division || !this.state.gender){
			alert("Please enter all field values to continue");
	}else{
	  console.log("Firstname: " + this.state.name);
        var newStudent = {name: this.state.name, dob: this.state.dob, stdclass: this.state.stdclass,division: this.state.division,gender: this.state.gender};
        this.props.createStudent(newStudent);   
		//clearing feilds after saving
		this.state = {};
		this.form.reset();
		alert("Student Registred");
	 }
   }
    
    render() {
        return (
            <div className="panel panel-default">
                <div className="panel-heading">Create student</div>
                <div className="panel-body">
                <form ref={form=> this.form = form}> 
                    <div className="col2-md-2">
						<label htmlFor="text">Name</label>  
                        <input type="text" placeholder="Name" className="form-control"  name="name" onChange={this.handleChange}/>    
                    </div>
                   <br></br>
                    <div className="col2-md-2">
					<label htmlFor="stdclass">Class</label>    
                            <select name="stdclass"  className="form-control"  onChange={this.handleChange}    
                                value={this.state.stdclass} >    
                                <option value="select">--Select--</option>    
                                <option value="I">I</option>    
                                <option value="II">II</option>    
                                <option value="III">III</option> 
								<option value="IV">IV</option>   
								 <option value="V">V</option>    
                                <option value="VI">VI</option>    
                                <option value="VII">VII</option> 
								<option value="VIII">VIII</option>
								<option value="IX">IX</option>   
								 <option value="X">X</option>    
                                <option value="XI">XI</option>    
                                <option value="XII">XII</option> 
                            </select>  
                    </div>
					 <br></br>
 						<div className="col2-md-2">         
                            <label htmlFor="text">Birth Date</label>    
                            <input  className="form-control"  type="date" name="dob"    
                                value={this.state.dob}    
                                onChange={this.handleChange}    
                                placeholder="DD/MM/YYYY.." />    
                               
                        </div>
 						<br></br>
						<div className="col2-md-2">    
                            <label htmlFor="division">Division</label>    
                            <select name="division"  className="form-control"  onChange={this.handleChange}    
                                value={this.state.division} >    
                                <option value="select">--Select--</option>    
                                <option value="a">A</option>    
                                <option value="b">B</option>    
                                <option value="c">C</option>    
                            </select>    
                             
                        </div>  
					<br></br>
					<div className="col2-md-2">    
                            <label htmlFor="gender">Gender</label>    

                           <input  type="radio" name="gender" 
                                   value="male" checked={this.state.gender === 'male'}
                                   onChange={this.handleChange} />Male
 							<input  type="radio" name="gender" 
                                   value="female" checked={this.state.gender === 'female'}
                                   onChange={this.handleChange} />Female
                             
                        </div>
					<br></br>
                    <div className="col-md-2">
                        <button className="btn btn-success" onClick={this.handleSubmit}>Save</button>   
                    </div>        
                </form>
                </div>      
            </div>
         
        );
    }
}

ReactDOM.render(<App />, document.getElementById('root') );